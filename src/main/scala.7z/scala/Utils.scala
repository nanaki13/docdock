package bon.jo
import scala.collection.mutable
object Utils extends App{
   lazy val t_usage = "Usage:"
   lazy  val t_options =  "Options:"
   lazy val t_mCmd = "Management Commands:"
   lazy  val t_cmds =  "Commands:"
   lazy val t_docker = "docker"
    lazy val noMatch = mutable.ListBuffer[String]()
    case class DockerParse(me : Iterator[String]) extends MarkIterator{
       
        def mark = {
           
            createMarkIfExists(t_usage)
            createMarkIfExists(t_options)
            createMarkIfExists(t_mCmd)
            createMarkIfExists(t_cmds) 
           
        }

       
       
    }

    def nullToOption[A](a : A) : Option[A] = {
      if(a!=null){
         Some(a)
      }else{
         None
      }
   }
   val headStr = "CONTAINER ID        IMAGE               COMMAND                  CREATED             STATUS                    PORTS               NAMES"
   println(contextReaderFactory.read(headStr).filter(_.isStart).map(_._offset))
   case class contextReader(current : Char,next : Option[Char],previous : Option[Char])(implicit str : String, offset : Int = 0){
      val _offset = offset
      def isStart = previous.isEmpty || {
        this match {
           case contextReader(' ',Some(v),Some(' ')) if v != ' '=> previousContext match {
              case Some(b) =>   b == contextReaderFactory.BLANK
              case _=> false
           }
           case _ => {false} 
        }
      } 
      def previousContext(implicit str : String, offset : Int) = contextReaderFactory(str)(offset -1)
      def isBlank = this == contextReaderFactory.BLANK
   }
   object contextReaderFactory{
      def BLANK(implicit str : String) = contextReader(' ',Some(' '),Some(' '))
      def apply( str : String)(implicit offset : Int  ) : Option[contextReader ]= if(str.nonEmpty) {
         val len = str.length()
         implicit val s = str
        Some( contextReader(
         str(offset),if(offset +1 < len) Some(str(offset +1))else None,if(offset -1 >= 0) Some(str(offset -1)) else None
         ))
         
      }else{None}

      def read(implicit str : String)  : IndexedSeq[contextReader] = {
         val r = 0 until str.length()
         for(  i <- r)yield {
            implicit val  ii :Int= i
            val c = contextReaderFactory(str)
            c match {
               case Some(value) => value
               case _ => throw new IllegalStateException(s"cant create reader on ${str}")
            }
         }
      }
   }

   def parse(str : String) = {

   }
}