package bon.jo
import collection.mutable

trait MarkIterator{
    def me : Iterator[String]
    val readed = mutable.ListBuffer[String]()
    me.copyToBuffer(readed)
    var marks : Map[String,Int] = Map()
    def findFirst(str : String):Option[Int] = {
        readed.zipWithIndex.find(_._1.contains(str)).map(_._2)
    }

    def createMark(str : String) = {
      
        marks +=  (str -> findFirst(str).get)
      
    }
    def createMarkIfExists(str : String) = {
  
        findFirst(str) match {
            case Some(value) =>  marks +=  (str -> value)
            case _ =>
        }
       
      
    }

    def getFrom(str : String) = {
        marks.get(str) match {
            case Some(value) => readed.slice( marks(str),readed.size)
            case None => Nil
        }
        
    }
    def getFrom(str : String,toEx : String) = {
        readed.slice( marks(str), marks(toEx))
    }

    def get(mark : String) : Option[String] = marks.get(mark) match {
        case Some(value) => Some(readed(value))
        case None => None
    }

}