package bon.jo
import akka.actor.ActorSystem
import akka.http.scaladsl.Http
import akka.http.scaladsl.server.HttpApp
import akka.http.scaladsl.model._
import akka.http.scaladsl.server.Directives._
import akka.stream.ActorMaterializer
import scala.io.StdIn
import DockerCommands._
import model._
import html._
import java.io.ByteArrayOutputStream
import akka.http.scaladsl.server.Route
object WebServer  extends HttpApp with App {


  val base = DockerAnalyse(List("--help")).getCommand
  val sideMenu = {
    val dsl = htmldsl()
    import dsl._
    val d :H =  "div"
    d.text =  "menu"
    base.map(_.cmd).foreach(e=>{
      dsl.link(e,"/dockdock/command/"+e+"/help" )(d)
       
    })
    dsl.ctx.root
    
  }

    val routeListCmdRunAndInfo =
    base.map{ c =>
      pathPrefix( "dockdock"/"command"/c.cmd) {
        concat(
          path("help"){
              val dsl = new htmlPagedsl()
                    import dsl._
              "div".content = sideMenu
            
              val linkTitle =  link("/dockdock/command/"+c.cmd+"/run" )
              val title =  <(linkTitle)("h1")
              title.text = c.cmd
            
              "p".text = c.desc
              "h2".text = "Usage : "
               "p".text = c.usage.get
             
              val opts = "div"
              val titleOption : H = "h3" 
              titleOption.text = "Options"
              opts.content = titleOption

              c.options match {
                case Some(ops) => {
                  ops.foreach(op=>{
                    implicit val contLocal : H = opts

                   "div".text = op.optionString
                   "div".text  = op.desc             
                })
              }
              case _ =>
            }
             
            
              complete(HttpEntity(ContentTypes.`text/html(UTF-8)`, dsl.template.toHTMLString) )
            }
          ,
          path("run"){
            parameters('options.?){
               (option)=>{
                   implicit val inErr = InErr()
       
                    val ret=  c.run(option)
                    val dsl = new htmlPagedsl()
                    import dsl._
                
                    "div".content = {
                      List(sideMenu)
                    }
                    "h4".text =  s"result (${ret}):"
                    "pre".text = inErr.out.toString()
                    "h4".text =  s"result (${ret}):"
                    "pre".text = inErr.err.toString()
                 
                    complete(HttpEntity(ContentTypes.`text/html(UTF-8)`,dsl.template.toHTMLString ))
               }
              }  
            }   
        ) 
      } 
    }
   
    def parsePs(outPs : String) = {

    }
    val manageRoute = path("dockdock"/"manage"){
      val doc = DockerCommands
      implicit val out : InErr = InErr()
      doc.d_ps.run(doc.d_ps.all)
     parsePs(  out.toString())
      val dsl = new htmlPagedsl()
      val pre =   dsl html "pre"
      pre.text =  out.out.toString   
      val err = dsl html  "pre"
      err.text =  err.toString  
      done(dsl) 
    }
    def done(e : htmlPagedsl) =  complete(HttpEntity(ContentTypes.`text/html(UTF-8)`,e.template.toHTMLString ))
    val routeListCommand =   path("dockdock"/"command") {
      val dsl = new htmlPagedsl()
      
      implicit val rt = dsl.ctx.root
      base.map(_.cmd).foreach(e=>{
        dsl.link(e,"/dockdock/command/"+e+"/help" )   
      })

      complete(HttpEntity(ContentTypes.`text/html(UTF-8)`, dsl.template.toHTMLString ))
    }
    val routeList = manageRoute::(routeListCommand :: routeListCmdRunAndInfo)
    override def routes: Route = get{concat(routeList : _ *)}
    override protected def postHttpBinding(binding: Http.ServerBinding): Unit = {
      super.postHttpBinding(binding)
      val sys = systemReference.get()
      sys.log.info(s"Running on [${sys.name}] actor system")
    }
  
    override protected def postHttpBindingFailure(cause: Throwable): Unit = {
      println(s"The server could not be started due to $cause")
    }

    // Starting the server
    WebServer.startServer("localhost", 8080)

    

  
}