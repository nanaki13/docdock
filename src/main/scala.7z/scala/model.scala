package bon.jo
import scala.io.Source
import scala.collection.mutable
import java.lang.ProcessBuilder.Redirect
import scala.jdk.CollectionConverters._
import html._
import java.io.StringReader
import scala.io.Codec
import java.io.OutputStream
import bon.jo.Utils._
package object model{
    
    val utf8 : Codec = Codec("utf-8")
  object Command{
  
     def toScala( command : Command) : String = {
  
         s"""object ${objectScalaName(command)}  extends Command("${command.cmd}","${command.desc}")${corp(command.options)}""".stripMargin
     }
  @inline 
  def objectScalaName(implicit command : Command) = s"`d_${command.cmd}`"
  def corp(options: Option[List[CommandOption]]): String = {
  
                   if(options.nonEmpty){
                    s"""{
                       
  ${options.get.map(CommandOption.toScala).map(e =>s"   ${e}").mkString("\n")}
  override val options =  Some(List(${options.get.map(CommandOption.scalaAlias).mkString(",")}))

  }"""
                 } else  ""
             
         
     }
  
  
  
  def htmlFile(cds :List[Command]) = {
        val dsl =  new htmlPagedsl()
        import dsl._
        cds.foreach(e=>{
           val a  =  "a" 
           a.atr  = (Map(("href"->s"./command/${e.cmd}.html")))
           a.text = e.cmd
     
           {
              val dsl =  new htmlPagedsl()
              import dsl._
              val p = "p"
              p.text = e.cmd
              val p2 = "p"
              p2.text = e.desc
    
              ctx.root.toHTMLFile(s"""./command/${e.cmd}.html""")
           }
             
            
        
        })
        
        ctx.root.toHTMLFile("index.html")
    }
   

  }
  
  object CommandOption{
     val reg = """(-[\w][\w-]*)?,?\s?(--[\w\d-]*)?\s?([\w-]*)?""".r
     def toScala( command : CommandOption) = s"""object ${scalaAlias (command)} extends CommandOption("${command.optionString}",""\"${command.desc}""\")""" 
     def scalaAlias( command : CommandOption) = s"`${command.parsed.long.get.replaceFirst("--","")}`"
  }
  case class ParsedOption(short : Option[String],long : Option[String],argType : Option[String])
  
  
  case class CommandOption(optionString : String,desc : String){
    
      val options = optionString.split(",").map(_.trim)
      override def toString() = "Options : "+ options.toList+" "+desc
     
  
      val parsed =  optionString match {
        case CommandOption.reg(a,b,c)  => ParsedOption(nullToOption(a),nullToOption(b),nullToOption(c))
        case s : String => print(s"no match for : ${s}");noMatch += optionString;ParsedOption(None,None,None)
     }
    
     
  }
  case class InErr( out : StringBuilder = new StringBuilder,err :StringBuilder= new StringBuilder )
   case class Command(
      cmd : String,
      desc : String, 
      options : Option[List[CommandOption]] = None,
      usageDesc : Option[List[UsageDesc]] = None,
      usage : Option[String] = None,
      ){
      val pb = new ProcessBuilder();
      
     def run :Int  = {
    
      pb.redirectOutput(Redirect.INHERIT)
      pb.redirectError(Redirect.INHERIT)
      pb.command("docker",cmd)
      val p = pb.start()
      p.waitFor()
     }
     val base =  List[String](  "docker", cmd)

     def run(out : OutputStream,err :OutputStream ):Int  = {
    
       
        pb.command("docker",cmd)
        val p = pb.start()
  
        Source.fromInputStream(p.getInputStream()).foldLeft(out)((out,c)=>{out.write(c);out})
        Source.fromInputStream(p.getErrorStream()).foldLeft(err)((err,c)=>{err.write(c);err})
        p.waitFor()
     }
     def run( options : Any with Product )(implicit o :InErr) = {
        val l : List[String] = options match {
            case e: CommandOption => List(e.parsed.long.get)
            case _ => ( for{
                e <- options.productIterator
            } yield {
                e match {
                    case e: CommandOption => e.parsed.long.get
                    case _ => ""
                }
            }).toList
        } 
        println(base++l.toList)
        pb.command((base++l.toList).asJava)
       val p =   pb.start()
       val readAndClose =   toBuilder( p )
        val ret= p.waitFor()
        readAndClose()
     }
     
     def toBuilder(p : Process)(implicit o :InErr ):()=>Unit ={
         val inSource =  Source.fromInputStream(p.getInputStream())(utf8)
         val errSource = Source.fromInputStream(p.getErrorStream())(utf8)
         def toBuider():Unit = {
            inSource.getLines().map(e=>e+"\n").foreach(o.out.append(_))
            errSource.getLines().map(e=>e+"\n").foreach(o.err.append(_))
            inSource.close()
            errSource.close()
         }
         toBuider _
     }
     def run(options : Option[String])(implicit o :InErr) :Int = {
    
        options match {
           case Some(value) =>  {
               
              pb.command((List[String](  "docker", cmd)++value.split(",").toList).asJava)
           }
           case None => pb.command("docker",cmd)
        }
       
        val p = pb.start()
        val readAndClose =  toBuilder(p)
        val ret= p.waitFor()
        readAndClose()
        ret
     }
  
     def runHelp = {
    
      pb.redirectOutput(Redirect.INHERIT)
      pb.redirectError(Redirect.INHERIT)
      pb.command("docker",cmd,"--help")
      val p = pb.start()
      p.waitFor()
     }
  
     def helpIteratorString :DockerParse = {
     
      pb.command("docker",cmd,"--help")
      
      val p = pb.start()
      val s = Source.fromInputStream( p.getInputStream())
  
      val lb = mutable.ListBuffer[String]()
      lb ++= s.getLines()
      val m = new DockerParse(lb.iterator)
      p.waitFor() 
      s.close
      m
     }
  }
  
  val usageReg = """docker [a-z]* (.*)""".r
 
  def desc(usage : String) : List[UsageDesc]= usage match {
     case usageReg(a) => a.split(" ").map(UsageDesc(_)).toList
     case _ => println("no");Nil
  }
 
  case class UsageDesc(str : String){
     def isOptional = str.startsWith("[")
     def cleanString = str.replaceFirst("\\[","").reverse.replaceFirst("\\]","").reverse
  }
  }